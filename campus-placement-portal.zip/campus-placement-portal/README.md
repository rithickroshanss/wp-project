# Campus Placement Portal

A full-stack MERN project for a college placement cell.
Students register, build a profile, search jobs and apply. Placement officers manage companies, jobs, applicants and announcements.

**Stack:** React (Vite) + React Router, Node.js + Express, MongoDB + Mongoose, JWT + bcrypt.

---

## 1. How it works (architecture)

```
Browser (React)  <-- JSON over HTTP -->  Express API  <-->  MongoDB
 pages and forms      rules and security     data storage
```

- **Frontend** (`frontend/`) shows pages. It only talks to the API and never sees secrets.
- **Backend** (`backend/`) checks every request: Is the user logged in (JWT)? Is the role allowed? Is the data valid?
- **Database** has 6 collections: `User`, `StudentProfile`, `Company`, `Job`, `Application`, `Announcement`.
- **Login:** the server checks the bcrypt password hash, returns a JWT, and React sends it in the `Authorization: Bearer <token>` header on every request.
- **No duplicate applications:** `Application` has a unique index on (job, student).
- **Eligibility** (min CGPA, branches, graduation year) is checked on the server when a student applies.
- **Resumes:** PDF/DOC/DOCX up to 2 MB. They are saved in `backend/uploads/` under server-chosen names and are **not** public. They can only be downloaded through protected API routes.

## 2. Folder structure

```
campus-placement-portal/
├── backend/
│   ├── config/db.js                 MongoDB connection
│   ├── controllers/                 the logic for each feature
│   ├── middleware/                  auth, validation, file upload, errors
│   ├── models/                      Mongoose schemas
│   ├── routes/                      URL -> controller wiring
│   ├── utils/                       helpers, constants, seed.js (sample data)
│   ├── uploads/                     saved resumes (git-ignored)
│   ├── .env.example                 copy to .env
│   ├── package.json
│   └── server.js                    app entry point
└── frontend/
    ├── src/
    │   ├── api/axios.js             API client (adds the token)
    │   ├── context/AuthContext.jsx  who is logged in
    │   ├── hooks/useFetch.js        loads data with loading/error state
    │   ├── components/              Navbar, Footer, JobCard, Loader, Alert, ProtectedRoute...
    │   ├── pages/                   Home, Login, Register, NotFound
    │   │   ├── student/             dashboard, profile, jobs, details, applications, announcements
    │   │   └── admin/               dashboard, students, companies, jobs, applicants, announcements
    │   ├── styles/main.css
    │   ├── App.jsx                  all routes
    │   └── main.jsx
    ├── index.html, vite.config.js, package.json, .env.example
```

## 3. Install the tools

1. **Node.js** (LTS 18 or newer): https://nodejs.org . Check with `node -v` and `npm -v`.
2. **VS Code**: https://code.visualstudio.com
3. **MongoDB**: pick ONE.
   - *Local:* install MongoDB Community Server and make sure it is running. The default URI in `.env.example` works as is.
   - *Atlas (cloud, free):* create a free cluster at https://www.mongodb.com/atlas , add a database user, allow your IP under Network Access, click Connect > Drivers, and copy the connection string into `MONGO_URI`.

## 4. Run the project

Open the `campus-placement-portal` folder in VS Code and open **two terminals** (Terminal > New Terminal).

**Terminal 1: backend**
```bash
cd backend
npm install
cp .env.example .env        # on Windows PowerShell: copy .env.example .env
```
Open `backend/.env` and set `MONGO_URI` and a long random `JWT_SECRET`
(generate one with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`).
```bash
npm run seed                # loads sample data (WARNING: wipes the database it points to)
npm run dev                 # starts the API on http://localhost:5000
```
You should see `MongoDB connected` and `Server running on http://localhost:5000`.

**Terminal 2: frontend**
```bash
cd frontend
npm install
npm run dev                 # opens on http://localhost:5173
```

## 5. Test accounts (created by `npm run seed`)

| Role | Email | Password |
|---|---|---|
| Admin | admin@college.edu | Admin@123 |
| Student | aarav@college.edu | Student@123 |
| Student | diya@college.edu | Student@123 |
| Student | rohan@college.edu | Student@123 |

Change these passwords before showing the project outside your college. New students can sign up from the Register page. Admin accounts can only be created by the seed script (or by changing `role` in the database), so nobody can make themselves an admin.

**Quick demo flow:**
1. Log in as Aarav: see the dashboard, open Jobs, apply to "Software Engineer".
2. Try the "Cloud Support Intern" job as Rohan: it shows why he is not eligible.
3. Log in as admin: open Jobs > Applicants, change a status to Shortlisted/Selected.
4. Log in as the student again: My applications shows the new status.
5. As admin, publish an announcement and check the student's Announcements page.

## 6. API summary

| Method | Endpoint | Who |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | public |
| GET | /api/auth/me | logged in |
| GET, PUT | /api/profile | student |
| POST, GET | /api/profile/resume | student |
| GET | /api/jobs, /api/jobs/:id | logged in (query: search, company, location, type, eligible) |
| POST, PUT, DELETE | /api/jobs, /api/jobs/:id | admin |
| GET | /api/companies | logged in |
| POST, PUT, DELETE | /api/companies, /api/companies/:id | admin |
| POST | /api/applications/:jobId | student |
| GET | /api/applications/my | student |
| GET, POST, DELETE | /api/announcements | read: logged in, write: admin |
| GET | /api/admin/stats, /api/admin/students | admin |
| DELETE | /api/admin/students/:id | admin |
| GET | /api/admin/students/:id/resume | admin |
| GET | /api/admin/jobs/:jobId/applicants | admin |
| PUT | /api/admin/applications/:id/status | admin |

## 7. Debugging common errors

| Problem | What to check |
|---|---|
| `Missing MONGO_URI or JWT_SECRET` | You did not create `backend/.env`. Copy it from `.env.example`. |
| `MongoDB connection failed` | Local: is MongoDB running? Atlas: correct password (URL-encode special characters), IP allowed in Network Access. |
| Frontend shows "Something went wrong" or network errors | Is the backend running on port 5000? Look at the backend terminal for the real error. |
| CORS error in the browser console | `CLIENT_URL` in `backend/.env` must match the frontend address exactly (e.g. `http://localhost:5173`). Restart the backend after editing `.env`. |
| 401 "session invalid" | The token expired or `JWT_SECRET` changed. Log in again. |
| "Complete your profile first" when applying | Student must set branch, CGPA and graduation year in Profile. |
| Resume upload fails | Only PDF, DOC, DOCX up to 2 MB. |
| `EADDRINUSE` port already in use | Another app uses that port. Stop it, or change `PORT` in `.env` (and the proxy in `frontend/vite.config.js`). |
| Blank page | Open the browser DevTools Console (F12) and read the first red error. |
| Changed `.env` but nothing changed | Restart the backend. `.env` is read only at start. |

Tip: in DevTools, the **Network** tab shows every API call and the server's error message.

## 8. Deploy

1. **Database:** use MongoDB Atlas. Allow your host's IPs (or 0.0.0.0/0 for a student project) under Network Access.
2. **Backend** (Render, Railway or similar): root directory `backend`, build command `npm install`, start command `npm start`. Add the environment variables `MONGO_URI`, `JWT_SECRET`, `JWT_EXPIRES_IN`, and `CLIENT_URL` (your frontend's final URL). Run `npm run seed` once from the host's shell to create the admin user, then change the admin password.
   - **Important:** many free hosts have a temporary disk, so uploaded resumes can disappear on restart. For real use, store resumes in cloud storage (e.g. Cloudinary or S3) or use a host with a persistent disk.
3. **Frontend** (Vercel or Netlify): root directory `frontend`, build command `npm run build`, output directory `dist`. Set `VITE_API_URL` to `https://<your-backend-url>/api`. For Netlify add a redirect `/* /index.html 200`; Vercel needs a rewrite of all paths to `/index.html` so that React Router pages work after a refresh.
4. Never commit `.env`. It is already in `.gitignore`.

## 9. Security notes

- Passwords are hashed with bcrypt. JWT secret and database URI live only in `backend/.env`.
- Every route is protected with JWT and checked by role (`student` or `admin`).
- All input is validated on the server (express-validator and Mongoose).
- The `helmet` package adds safe HTTP headers. CORS only allows your frontend address.
- Search text is escaped before use in regular expressions.
- Ideas for later: rate-limit login attempts (`express-rate-limit`), email verification, password reset.
