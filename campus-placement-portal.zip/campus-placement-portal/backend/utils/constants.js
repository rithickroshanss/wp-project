module.exports = {
  BRANCHES: ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"],
  STATUSES: ["Applied", "Shortlisted", "Selected", "Rejected"],
  JOB_TYPES: ["Full-time", "Internship"],
};
