// Makes user text safe to use inside a RegExp search.
module.exports = (text) => new RegExp(String(text).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
