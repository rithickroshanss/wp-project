// Fills the database with sample data.  Run:  npm run seed
// WARNING: this deletes existing data in the database first.
require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../models/User");
const StudentProfile = require("../models/StudentProfile");
const Company = require("../models/Company");
const Job = require("../models/Job");
const Application = require("../models/Application");
const Announcement = require("../models/Announcement");

const daysFromNow = (n) => new Date(Date.now() + n * 24 * 60 * 60 * 1000);

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User, StudentProfile, Company, Job, Application, Announcement].map((m) => m.deleteMany({})));

  const admin = await User.create({ name: "Placement Officer", email: "admin@college.edu", password: "Admin@123", role: "admin" });

  const students = [];
  const data = [
    ["Aarav Kumar", "aarav@college.edu", "21CS001", "CSE", 8.7, ["JavaScript", "React", "MongoDB"]],
    ["Diya Sharma", "diya@college.edu", "21IT014", "IT", 7.9, ["Java", "SQL"]],
    ["Rohan Mehta", "rohan@college.edu", "21EC027", "ECE", 6.8, ["C", "Embedded Systems"]],
  ];
  for (const [name, email, rollNumber, branch, cgpa, skills] of data) {
    const user = await User.create({ name, email, password: "Student@123", role: "student" });
    await StudentProfile.create({ user: user._id, rollNumber, branch, cgpa, graduationYear: 2026, phone: "9876543210", skills });
    students.push(user);
  }

  const [techNova, infraWorks, circuitLabs] = await Company.create([
    { name: "TechNova Solutions", description: "Product and services company building web platforms.", website: "https://technova.example.com", location: "Chennai" },
    { name: "InfraWorks", description: "Cloud and infrastructure consulting.", website: "https://infraworks.example.com", location: "Bengaluru" },
    { name: "CircuitLabs", description: "Electronics and embedded systems design.", website: "https://circuitlabs.example.com", location: "Hyderabad" },
  ]);

  const [j1, j2, j3] = await Job.create([
    { company: techNova._id, title: "Software Engineer", description: "Build and maintain web applications using React and Node.js.", location: "Chennai", type: "Full-time", salary: "6 LPA", minCgpa: 7.5, eligibleBranches: ["CSE", "IT"], graduationYear: 2026, deadline: daysFromNow(20) },
    { company: infraWorks._id, title: "Cloud Support Intern", description: "Six-month internship supporting cloud deployments.", location: "Bengaluru", type: "Internship", salary: "20,000 / month", minCgpa: 7, eligibleBranches: ["CSE", "IT", "ECE"], graduationYear: 2026, deadline: daysFromNow(10) },
    { company: circuitLabs._id, title: "Embedded Engineer", description: "Design firmware for IoT devices.", location: "Hyderabad", type: "Full-time", salary: "5 LPA", minCgpa: 6.5, eligibleBranches: ["ECE", "EEE"], graduationYear: 2026, deadline: daysFromNow(30) },
  ]);

  await Application.create([
    { job: j1._id, student: students[0]._id, status: "Shortlisted" },
    { job: j2._id, student: students[1]._id, status: "Applied" },
    { job: j3._id, student: students[2]._id, status: "Applied" },
  ]);

  await Announcement.create([
    { title: "Pre-placement talk: TechNova", message: "TechNova will hold a pre-placement talk in the seminar hall this Friday at 10 AM.", createdBy: admin._id },
    { title: "Resume submission", message: "Upload your latest resume in your profile before applying to any job.", createdBy: admin._id },
  ]);

  console.log("Sample data created.\nAdmin:   admin@college.edu / Admin@123\nStudent: aarav@college.edu / Student@123");
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
