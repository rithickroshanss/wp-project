// Decides if a student can apply to a job.
exports.checkEligibility = (job, profile) => {
  if (!profile || profile.cgpa == null || !profile.branch || !profile.graduationYear) {
    return { eligible: false, reason: "Complete your profile (branch, CGPA, graduation year) first." };
  }
  if (profile.cgpa < (job.minCgpa || 0)) {
    return { eligible: false, reason: `Minimum CGPA required is ${job.minCgpa}.` };
  }
  if (job.eligibleBranches?.length && !job.eligibleBranches.includes(profile.branch)) {
    return { eligible: false, reason: `Open only to: ${job.eligibleBranches.join(", ")}.` };
  }
  if (job.graduationYear && job.graduationYear !== profile.graduationYear) {
    return { eligible: false, reason: `Open only to the ${job.graduationYear} batch.` };
  }
  return { eligible: true, reason: "" };
};
