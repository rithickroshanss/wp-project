const Announcement = require("../models/Announcement");
const asyncHandler = require("../utils/asyncHandler");

exports.getAnnouncements = asyncHandler(async (req, res) => {
  res.json(await Announcement.find().populate("createdBy", "name").sort({ createdAt: -1 }));
});

exports.createAnnouncement = asyncHandler(async (req, res) => {
  const { title, message } = req.body;
  res.status(201).json(await Announcement.create({ title, message, createdBy: req.user._id }));
});

exports.deleteAnnouncement = asyncHandler(async (req, res) => {
  const item = await Announcement.findByIdAndDelete(req.params.id);
  if (!item) return res.status(404).json({ message: "Announcement not found." });
  res.json({ message: "Announcement deleted." });
});
