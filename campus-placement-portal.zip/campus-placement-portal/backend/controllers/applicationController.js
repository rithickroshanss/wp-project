const Application = require("../models/Application");
const Job = require("../models/Job");
const StudentProfile = require("../models/StudentProfile");
const asyncHandler = require("../utils/asyncHandler");
const { checkEligibility } = require("../utils/eligibility");

// POST /api/applications/:jobId   (student)
exports.apply = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.jobId);
  if (!job || !job.isActive) return res.status(404).json({ message: "Job not found." });
  if (job.deadline < new Date()) return res.status(400).json({ message: "The deadline for this job has passed." });

  const profile = await StudentProfile.findOne({ user: req.user._id });
  const { eligible, reason } = checkEligibility(job, profile);
  if (!eligible) return res.status(400).json({ message: reason });

  try {
    const application = await Application.create({ job: job._id, student: req.user._id });
    res.status(201).json(application);
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: "You have already applied to this job." });
    throw err;
  }
});

// GET /api/applications/my   (student)
exports.myApplications = asyncHandler(async (req, res) => {
  const apps = await Application.find({ student: req.user._id })
    .populate({ path: "job", select: "title location deadline", populate: { path: "company", select: "name" } })
    .sort({ createdAt: -1 });
  res.json(apps.filter((a) => a.job)); // skip applications whose job was deleted
});

// GET /api/admin/jobs/:jobId/applicants   (admin)
exports.jobApplicants = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.jobId).populate("company", "name");
  if (!job) return res.status(404).json({ message: "Job not found." });
  const apps = (await Application.find({ job: job._id }).populate("student", "name email").sort({ createdAt: -1 }).lean())
    .filter((a) => a.student);
  const profiles = await StudentProfile.find({ user: { $in: apps.map((a) => a.student._id) } }).lean();
  const byUser = Object.fromEntries(profiles.map((p) => [String(p.user), p]));
  const applicants = apps.map((a) => {
    const p = byUser[String(a.student._id)] || {};
    return {
      _id: a._id, status: a.status, appliedAt: a.createdAt,
      student: { _id: a.student._id, name: a.student.name, email: a.student.email },
      rollNumber: p.rollNumber, branch: p.branch, cgpa: p.cgpa, hasResume: !!p.resume?.path,
    };
  });
  res.json({ job: { _id: job._id, title: job.title, company: job.company?.name }, applicants });
});

// PUT /api/admin/applications/:id/status   (admin)
exports.updateStatus = asyncHandler(async (req, res) => {
  const app = await Application.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!app) return res.status(404).json({ message: "Application not found." });
  res.json(app);
});
