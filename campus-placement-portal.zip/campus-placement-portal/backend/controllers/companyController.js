const Company = require("../models/Company");
const Job = require("../models/Job");
const asyncHandler = require("../utils/asyncHandler");

const fields = ["name", "description", "website", "location"];
const pick = (body) => Object.fromEntries(fields.filter((f) => body[f] !== undefined).map((f) => [f, body[f]]));

exports.getCompanies = asyncHandler(async (req, res) => {
  res.json(await Company.find().sort({ name: 1 }));
});

exports.createCompany = asyncHandler(async (req, res) => {
  res.status(201).json(await Company.create(pick(req.body)));
});

exports.updateCompany = asyncHandler(async (req, res) => {
  const company = await Company.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!company) return res.status(404).json({ message: "Company not found." });
  res.json(company);
});

exports.deleteCompany = asyncHandler(async (req, res) => {
  if (await Job.exists({ company: req.params.id })) {
    return res.status(400).json({ message: "Delete this company's jobs first." });
  }
  const company = await Company.findByIdAndDelete(req.params.id);
  if (!company) return res.status(404).json({ message: "Company not found." });
  res.json({ message: "Company deleted." });
});
