const fs = require("fs");
const path = require("path");
const User = require("../models/User");
const StudentProfile = require("../models/StudentProfile");
const Company = require("../models/Company");
const Job = require("../models/Job");
const Application = require("../models/Application");
const asyncHandler = require("../utils/asyncHandler");
const { uploadDir } = require("../middleware/uploadMiddleware");
const { sendResume } = require("./profileController");
const { STATUSES } = require("../utils/constants");

// GET /api/admin/stats
exports.stats = asyncHandler(async (req, res) => {
  const [students, companies, jobs, applications, grouped] = await Promise.all([
    User.countDocuments({ role: "student" }),
    Company.countDocuments(),
    Job.countDocuments(),
    Application.countDocuments(),
    Application.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
  ]);
  const byStatus = Object.fromEntries(STATUSES.map((s) => [s, 0]));
  grouped.forEach((g) => (byStatus[g._id] = g.count));
  res.json({ students, companies, jobs, applications, byStatus });
});

// GET /api/admin/students?search=
exports.listStudents = asyncHandler(async (req, res) => {
  const users = await User.find({ role: "student" }).sort({ createdAt: -1 }).lean();
  const profiles = await StudentProfile.find({ user: { $in: users.map((u) => u._id) } }).lean();
  const byUser = Object.fromEntries(profiles.map((p) => [String(p.user), p]));
  res.json(
    users.map((u) => {
      const p = byUser[String(u._id)] || {};
      return {
        _id: u._id, name: u.name, email: u.email, rollNumber: p.rollNumber, branch: p.branch,
        cgpa: p.cgpa, graduationYear: p.graduationYear, skills: p.skills || [], hasResume: !!p.resume?.path,
      };
    })
  );
});

// DELETE /api/admin/students/:id
exports.deleteStudent = asyncHandler(async (req, res) => {
  const user = await User.findOne({ _id: req.params.id, role: "student" });
  if (!user) return res.status(404).json({ message: "Student not found." });
  const profile = await StudentProfile.findOne({ user: user._id });
  if (profile?.resume?.path) fs.unlink(path.join(uploadDir, path.basename(profile.resume.path)), () => {});
  await Promise.all([
    StudentProfile.deleteOne({ user: user._id }),
    Application.deleteMany({ student: user._id }),
    user.deleteOne(),
  ]);
  res.json({ message: "Student removed." });
});

// GET /api/admin/students/:id/resume
exports.studentResume = asyncHandler(async (req, res) => sendResume(req.params.id, res));
