const Job = require("../models/Job");
const Company = require("../models/Company");
const Application = require("../models/Application");
const StudentProfile = require("../models/StudentProfile");
const asyncHandler = require("../utils/asyncHandler");
const toRegex = require("../utils/regex");
const { checkEligibility } = require("../utils/eligibility");

const fields = ["company", "title", "description", "location", "type", "salary", "minCgpa", "eligibleBranches", "graduationYear", "deadline", "isActive"];
const pick = (body) => Object.fromEntries(fields.filter((f) => body[f] !== undefined).map((f) => [f, body[f]]));

// For students, add "eligible", "reason" and "applied" to each job.
const decorateForStudent = async (user, jobs) => {
  const profile = await StudentProfile.findOne({ user: user._id }).lean();
  const apps = await Application.find({ student: user._id }).select("job").lean();
  const applied = new Set(apps.map((a) => String(a.job)));
  return jobs.map((j) => ({ ...j, ...checkEligibility(j, profile), applied: applied.has(String(j._id)) }));
};

// GET /api/jobs?search=&company=&location=&type=&eligible=true
exports.getJobs = asyncHandler(async (req, res) => {
  const { search, company, location, type, eligible } = req.query;
  const filter = {};
  const isStudent = req.user.role === "student";
  if (isStudent) filter.isActive = true;
  if (search) filter.title = toRegex(search);
  if (location) filter.location = toRegex(location);
  if (type) filter.type = type;
  if (company) {
    const matches = await Company.find({ name: toRegex(company) }).select("_id");
    filter.company = { $in: matches.map((c) => c._id) };
  }
  let jobs = await Job.find(filter).populate("company", "name location website").sort({ createdAt: -1 }).lean();
  if (isStudent) {
    jobs = await decorateForStudent(req.user, jobs);
    if (eligible === "true") jobs = jobs.filter((j) => j.eligible);
  }
  res.json(jobs);
});

// GET /api/jobs/:id
exports.getJob = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate("company").lean();
  if (!job) return res.status(404).json({ message: "Job not found." });
  if (req.user.role === "student") {
    if (!job.isActive) return res.status(404).json({ message: "Job not found." });
    return res.json((await decorateForStudent(req.user, [job]))[0]);
  }
  res.json(job);
});

exports.createJob = asyncHandler(async (req, res) => {
  if (!(await Company.exists({ _id: req.body.company }))) {
    return res.status(400).json({ message: "Selected company does not exist." });
  }
  res.status(201).json(await Job.create(pick(req.body)));
});

exports.updateJob = asyncHandler(async (req, res) => {
  const job = await Job.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!job) return res.status(404).json({ message: "Job not found." });
  res.json(job);
});

exports.deleteJob = asyncHandler(async (req, res) => {
  const job = await Job.findByIdAndDelete(req.params.id);
  if (!job) return res.status(404).json({ message: "Job not found." });
  await Application.deleteMany({ job: job._id });
  res.json({ message: "Job deleted." });
});
