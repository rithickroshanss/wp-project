const fs = require("fs");
const path = require("path");
const StudentProfile = require("../models/StudentProfile");
const asyncHandler = require("../utils/asyncHandler");
const { uploadDir } = require("../middleware/uploadMiddleware");

const getOrCreate = async (userId) =>
  (await StudentProfile.findOne({ user: userId })) || (await StudentProfile.create({ user: userId }));

const withUser = (profile, user) => ({ ...profile.toObject(), name: user.name, email: user.email });

// GET /api/profile
exports.getProfile = asyncHandler(async (req, res) => {
  res.json(withUser(await getOrCreate(req.user._id), req.user));
});

// PUT /api/profile
exports.updateProfile = asyncHandler(async (req, res) => {
  const profile = await getOrCreate(req.user._id);
  ["rollNumber", "branch", "cgpa", "graduationYear", "phone"].forEach((f) => {
    if (req.body[f] !== undefined && req.body[f] !== "") profile[f] = req.body[f];
  });
  if (req.body.skills !== undefined) {
    const list = Array.isArray(req.body.skills) ? req.body.skills : String(req.body.skills).split(",");
    profile.skills = list.map((s) => s.trim()).filter(Boolean);
  }
  await profile.save();
  if (req.body.name && req.body.name !== req.user.name) {
    req.user.name = req.body.name;
    await req.user.save();
  }
  res.json(withUser(profile, req.user));
});

// POST /api/profile/resume
exports.uploadResume = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: "Please choose a resume file." });
  const profile = await getOrCreate(req.user._id);
  if (profile.resume?.path) fs.unlink(path.join(uploadDir, profile.resume.path), () => {});
  profile.resume = { path: req.file.filename, originalName: req.file.originalname };
  await profile.save();
  res.json(withUser(profile, req.user));
});

// Sends a stored resume. Used by the student (own) and the admin (any student).
exports.sendResume = async (userId, res) => {
  const profile = await StudentProfile.findOne({ user: userId });
  if (!profile?.resume?.path) return res.status(404).json({ message: "No resume uploaded." });
  const file = path.join(uploadDir, path.basename(profile.resume.path));
  if (!fs.existsSync(file)) return res.status(404).json({ message: "Resume file is missing." });
  res.download(file, profile.resume.originalName);
};

// GET /api/profile/resume
exports.downloadMyResume = asyncHandler(async (req, res) => exports.sendResume(req.user._id, res));
