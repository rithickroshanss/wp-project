const User = require("../models/User");
const asyncHandler = require("../utils/asyncHandler");
const { signToken, publicUser } = require("../utils/token");

// POST /api/auth/register  (students only; admins are created by the seed script)
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.findOne({ email })) {
    return res.status(409).json({ message: "An account with this email already exists." });
  }
  const user = await User.create({ name, email, password, role: "student" });
  res.status(201).json({ token: signToken(user._id), user: publicUser(user) });
});

// POST /api/auth/login
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select("+password");
  if (!user || !(await user.matchPassword(password))) {
    return res.status(401).json({ message: "Wrong email or password." });
  }
  res.json({ token: signToken(user._id), user: publicUser(user) });
});

// GET /api/auth/me
exports.me = asyncHandler(async (req, res) => {
  res.json(publicUser(req.user));
});
