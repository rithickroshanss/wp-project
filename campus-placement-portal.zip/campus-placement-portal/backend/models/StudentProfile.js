const mongoose = require("mongoose");
const { BRANCHES } = require("../utils/constants");

const profileSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
    rollNumber: { type: String, trim: true },
    branch: { type: String, enum: BRANCHES },
    cgpa: { type: Number, min: 0, max: 10 },
    graduationYear: { type: Number },
    phone: { type: String, trim: true },
    skills: [{ type: String, trim: true }],
    resume: { path: String, originalName: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("StudentProfile", profileSchema);
