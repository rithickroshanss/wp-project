const mongoose = require("mongoose");
const { JOB_TYPES } = require("../utils/constants");

const jobSchema = new mongoose.Schema(
  {
    company: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true },
    title: { type: String, required: [true, "Job title is required"], trim: true },
    description: { type: String, required: [true, "Description is required"], trim: true },
    location: { type: String, required: [true, "Location is required"], trim: true },
    type: { type: String, enum: JOB_TYPES, default: "Full-time" },
    salary: { type: String, trim: true },
    minCgpa: { type: Number, min: 0, max: 10, default: 0 },
    eligibleBranches: [{ type: String }], // empty = all branches
    graduationYear: { type: Number },
    deadline: { type: Date, required: [true, "Deadline is required"] },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Job", jobSchema);
