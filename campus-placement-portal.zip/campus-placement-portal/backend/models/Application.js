const mongoose = require("mongoose");
const { STATUSES } = require("../utils/constants");

const applicationSchema = new mongoose.Schema(
  {
    job: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, enum: STATUSES, default: "Applied" },
  },
  { timestamps: true }
);

// The database itself refuses a second application to the same job.
applicationSchema.index({ job: 1, student: 1 }, { unique: true });

module.exports = mongoose.model("Application", applicationSchema);
