const mongoose = require("mongoose");

const companySchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, "Company name is required"], unique: true, trim: true },
    description: { type: String, trim: true },
    website: { type: String, trim: true },
    location: { type: String, trim: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Company", companySchema);
