const router = require("express").Router();
const { body } = require("express-validator");
const { register, login, me } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");
const validate = require("../middleware/validate");

router.post(
  "/register",
  [
    body("name").trim().notEmpty().withMessage("Name is required").isLength({ max: 80 }).withMessage("Name is too long"),
    body("email").trim().isEmail().withMessage("Enter a valid email").normalizeEmail(),
    body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  ],
  validate,
  register
);
router.post(
  "/login",
  [body("email").trim().isEmail().withMessage("Enter a valid email").normalizeEmail(), body("password").notEmpty().withMessage("Password is required")],
  validate,
  login
);
router.get("/me", protect, me);

module.exports = router;
