const router = require("express").Router();
const { body } = require("express-validator");
const c = require("../controllers/jobController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validate = require("../middleware/validate");
const { BRANCHES, JOB_TYPES } = require("../utils/constants");

const rules = [
  body("company").isMongoId().withMessage("Select a company"),
  body("title").trim().notEmpty().withMessage("Job title is required"),
  body("description").trim().notEmpty().withMessage("Description is required"),
  body("location").trim().notEmpty().withMessage("Location is required"),
  body("type").optional().isIn(JOB_TYPES).withMessage("Invalid job type"),
  body("minCgpa").optional({ values: "falsy" }).isFloat({ min: 0, max: 10 }).withMessage("Minimum CGPA must be between 0 and 10"),
  body("eligibleBranches").optional().isArray().withMessage("Eligible branches must be a list"),
  body("eligibleBranches.*").isIn(BRANCHES).withMessage("Invalid branch"),
  body("graduationYear").optional({ values: "falsy" }).isInt({ min: 2000, max: 2100 }).withMessage("Enter a valid graduation year"),
  body("deadline").isISO8601().withMessage("Enter a valid deadline date"),
];

router.use(protect);
router.get("/", c.getJobs);
router.get("/:id", c.getJob);
router.post("/", authorize("admin"), rules, validate, c.createJob);
router.put("/:id", authorize("admin"), rules, validate, c.updateJob);
router.delete("/:id", authorize("admin"), c.deleteJob);

module.exports = router;
