const router = require("express").Router();
const { apply, myApplications } = require("../controllers/applicationController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.use(protect, authorize("student"));
router.get("/my", myApplications);
router.post("/:jobId", apply);

module.exports = router;
