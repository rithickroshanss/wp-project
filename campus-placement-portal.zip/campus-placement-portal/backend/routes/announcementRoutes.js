const router = require("express").Router();
const { body } = require("express-validator");
const c = require("../controllers/announcementController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validate = require("../middleware/validate");

router.use(protect);
router.get("/", c.getAnnouncements);
router.post(
  "/",
  authorize("admin"),
  [body("title").trim().notEmpty().withMessage("Title is required"), body("message").trim().notEmpty().withMessage("Message is required")],
  validate,
  c.createAnnouncement
);
router.delete("/:id", authorize("admin"), c.deleteAnnouncement);

module.exports = router;
