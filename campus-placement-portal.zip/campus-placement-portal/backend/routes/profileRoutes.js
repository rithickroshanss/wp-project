const router = require("express").Router();
const { body } = require("express-validator");
const { getProfile, updateProfile, uploadResume, downloadMyResume } = require("../controllers/profileController");
const { protect, authorize } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");
const validate = require("../middleware/validate");
const { BRANCHES } = require("../utils/constants");

router.use(protect, authorize("student"));

router.get("/", getProfile);
router.put(
  "/",
  [
    body("name").optional().trim().notEmpty().withMessage("Name cannot be empty"),
    body("rollNumber").optional({ values: "falsy" }).trim().isLength({ max: 30 }).withMessage("Roll number is too long"),
    body("branch").optional({ values: "falsy" }).isIn(BRANCHES).withMessage(`Branch must be one of: ${BRANCHES.join(", ")}`),
    body("cgpa").optional({ values: "falsy" }).isFloat({ min: 0, max: 10 }).withMessage("CGPA must be between 0 and 10"),
    body("graduationYear").optional({ values: "falsy" }).isInt({ min: 2000, max: 2100 }).withMessage("Enter a valid graduation year"),
    body("phone").optional({ values: "falsy" }).matches(/^[0-9+\-\s]{7,15}$/).withMessage("Enter a valid phone number"),
  ],
  validate,
  updateProfile
);
router.post("/resume", upload.single("resume"), uploadResume);
router.get("/resume", downloadMyResume);

module.exports = router;
