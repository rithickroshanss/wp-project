const router = require("express").Router();
const { body } = require("express-validator");
const admin = require("../controllers/adminController");
const { jobApplicants, updateStatus } = require("../controllers/applicationController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validate = require("../middleware/validate");
const { STATUSES } = require("../utils/constants");

router.use(protect, authorize("admin"));

router.get("/stats", admin.stats);
router.get("/students", admin.listStudents);
router.delete("/students/:id", admin.deleteStudent);
router.get("/students/:id/resume", admin.studentResume);
router.get("/jobs/:jobId/applicants", jobApplicants);
router.put(
  "/applications/:id/status",
  [body("status").isIn(STATUSES).withMessage(`Status must be one of: ${STATUSES.join(", ")}`)],
  validate,
  updateStatus
);

module.exports = router;
