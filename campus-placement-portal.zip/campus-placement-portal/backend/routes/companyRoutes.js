const router = require("express").Router();
const { body } = require("express-validator");
const c = require("../controllers/companyController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validate = require("../middleware/validate");

const rules = [
  body("name").trim().notEmpty().withMessage("Company name is required"),
  body("website").optional({ values: "falsy" }).isURL().withMessage("Enter a valid website URL (include https://)"),
];

router.use(protect);
router.get("/", c.getCompanies);
router.post("/", authorize("admin"), rules, validate, c.createCompany);
router.put("/:id", authorize("admin"), rules, validate, c.updateCompany);
router.delete("/:id", authorize("admin"), c.deleteCompany);

module.exports = router;
