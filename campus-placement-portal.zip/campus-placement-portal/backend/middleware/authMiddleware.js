const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Checks the JWT token and loads the logged-in user into req.user
exports.protect = async (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    if (!header.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Please log in to continue." });
    }
    const decoded = jwt.verify(header.split(" ")[1], process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ message: "This account no longer exists." });
    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({ message: "Your session is invalid or expired. Please log in again." });
  }
};

// Allows only certain roles, e.g. authorize("admin")
exports.authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ message: "You do not have permission to do this." });
  }
  next();
};
