exports.notFound = (req, res) => {
  res.status(404).json({ message: `Route not found: ${req.originalUrl}` });
};

exports.errorHandler = (err, req, res, next) => {
  let status = err.status || 500;
  let message = err.message || "Server error";

  if (err.name === "MulterError") {
    status = 400;
    message = err.code === "LIMIT_FILE_SIZE" ? "Resume must be 2 MB or smaller." : err.message;
  } else if (err.name === "ValidationError") {
    status = 400;
    message = Object.values(err.errors).map((e) => e.message).join(", ");
  } else if (err.name === "CastError") {
    status = 400;
    message = "Invalid id.";
  } else if (err.code === 11000) {
    status = 409;
    message = "This record already exists.";
  }

  if (status === 500) console.error(err);
  res.status(status).json({ message: status === 500 ? "Server error. Please try again." : message });
};
