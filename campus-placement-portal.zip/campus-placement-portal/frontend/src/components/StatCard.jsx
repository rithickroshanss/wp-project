export default function StatCard({ label, value, hint }) {
  return (
    <div className="card stat-card">
      <div className="stat-value">{value ?? "-"}</div>
      <div className="stat-label">{label}</div>
      {hint && <div className="muted small">{hint}</div>}
    </div>
  );
}
