import { Link } from "react-router-dom";

export default function JobCard({ job }) {
  return (
    <article className="card job-card">
      <div className="job-card-top">
        <div>
          <h3>{job.title}</h3>
          <p className="muted">{job.company?.name}</p>
        </div>
        {job.applied ? (
          <span className="badge badge-Selected">Applied</span>
        ) : job.eligible === false ? (
          <span className="badge badge-Rejected">Not eligible</span>
        ) : null}
      </div>
      <ul className="job-meta">
        <li>{job.location}</li>
        <li>{job.type}</li>
        {job.salary && <li>{job.salary}</li>}
        <li>Min CGPA {job.minCgpa}</li>
      </ul>
      <p className="small muted">Apply by {new Date(job.deadline).toLocaleDateString()}</p>
      <Link to={`/jobs/${job._id}`} className="btn btn-outline btn-sm">
        View details
      </Link>
    </article>
  );
}
