export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <span>Campus Placement Portal</span>
        <span className="muted">Training and Placement Cell. Questions? Contact your placement officer.</span>
      </div>
    </footer>
  );
}
