import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const studentLinks = [
  ["/dashboard", "Dashboard"],
  ["/jobs", "Jobs"],
  ["/applications", "My applications"],
  ["/announcements", "Announcements"],
  ["/profile", "Profile"],
];
const adminLinks = [
  ["/admin", "Dashboard"],
  ["/admin/students", "Students"],
  ["/admin/companies", "Companies"],
  ["/admin/jobs", "Jobs"],
  ["/admin/announcements", "Announcements"],
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const links = !user ? [] : user.role === "admin" ? adminLinks : studentLinks;

  const handleLogout = () => {
    logout();
    setOpen(false);
    navigate("/");
  };

  return (
    <header className="navbar">
      <div className="container navbar-inner">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          Campus Placement
        </Link>
        <button className="nav-toggle" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>
          Menu
        </button>
        <nav className={`nav-links ${open ? "open" : ""}`}>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/admin"} onClick={() => setOpen(false)}>
              {label}
            </NavLink>
          ))}
          {user ? (
            <button className="btn btn-light btn-sm" onClick={handleLogout}>
              Log out ({user.name.split(" ")[0]})
            </button>
          ) : (
            <>
              <NavLink to="/login" onClick={() => setOpen(false)}>Log in</NavLink>
              <Link to="/register" className="btn btn-accent btn-sm" onClick={() => setOpen(false)}>
                Register
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
