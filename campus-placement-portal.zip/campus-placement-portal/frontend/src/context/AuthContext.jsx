import { createContext, useContext, useEffect, useState } from "react";
import api from "../api/axios";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem("token"));

  // On page load, check if the saved token is still valid.
  useEffect(() => {
    if (!localStorage.getItem("token")) return;
    api
      .get("/auth/me")
      .then((res) => setUser(res.data))
      .catch(() => localStorage.removeItem("token"))
      .finally(() => setLoading(false));
  }, []);

  const startSession = ({ token, user }) => {
    localStorage.setItem("token", token);
    setUser(user);
    return user;
  };

  const login = async (email, password) => startSession((await api.post("/auth/login", { email, password })).data);
  const register = async (name, email, password) =>
    startSession((await api.post("/auth/register", { name, email, password })).data);
  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
  };

  return <AuthContext.Provider value={{ user, loading, login, register, logout }}>{children}</AuthContext.Provider>;
}
