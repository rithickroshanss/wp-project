import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

export default function Announcements() {
  const { data, loading, error } = useFetch("/announcements");

  return (
    <>
      <div className="page-head">
        <h1>Placement announcements</h1>
      </div>
      <Alert message={error} />
      {loading ? (
        <Loader />
      ) : data?.length ? (
        <div className="grid">
          {data.map((n) => (
            <article key={n._id} className="card announce">
              <h3>{n.title}</h3>
              <p style={{ whiteSpace: "pre-line" }}>{n.message}</p>
              <span className="small muted">
                {new Date(n.createdAt).toLocaleDateString()} {n.createdBy?.name && `by ${n.createdBy.name}`}
              </span>
            </article>
          ))}
        </div>
      ) : (
        !error && <div className="card empty">No announcements yet.</div>
      )}
    </>
  );
}
