import { useState } from "react";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";
import JobCard from "../../components/JobCard";

const empty = { search: "", company: "", location: "", type: "", eligible: "" };

export default function Jobs() {
  const [filters, setFilters] = useState(empty);
  const [applied, setApplied] = useState(empty); // filters actually sent to the server

  const query = new URLSearchParams(Object.entries(applied).filter(([, v]) => v)).toString();
  const { data, loading, error } = useFetch(`/jobs?${query}`);

  const change = (e) => {
    const { name, type, checked, value } = e.target;
    setFilters({ ...filters, [name]: type === "checkbox" ? (checked ? "true" : "") : value });
  };
  const submit = (e) => { e.preventDefault(); setApplied(filters); };
  const reset = () => { setFilters(empty); setApplied(empty); };

  return (
    <>
      <div className="page-head">
        <h1>Available jobs</h1>
        <p className="muted">Search by role, company or location.</p>
      </div>

      <form className="card filters" onSubmit={submit}>
        <div className="form-group"><label htmlFor="search">Role</label><input id="search" name="search" value={filters.search} onChange={change} placeholder="e.g. Engineer" /></div>
        <div className="form-group"><label htmlFor="company">Company</label><input id="company" name="company" value={filters.company} onChange={change} /></div>
        <div className="form-group"><label htmlFor="location">Location</label><input id="location" name="location" value={filters.location} onChange={change} /></div>
        <div className="form-group">
          <label htmlFor="type">Type</label>
          <select id="type" name="type" value={filters.type} onChange={change}>
            <option value="">All</option><option>Full-time</option><option>Internship</option>
          </select>
        </div>
        <div>
          <div className="checks" style={{ marginBottom: "0.5rem" }}>
            <label><input type="checkbox" name="eligible" checked={filters.eligible === "true"} onChange={change} /> Eligible for me</label>
          </div>
          <div className="row">
            <button className="btn btn-primary btn-sm">Search</button>
            <button type="button" className="btn btn-outline btn-sm" onClick={reset}>Clear</button>
          </div>
        </div>
      </form>

      <Alert message={error} />
      {loading ? (
        <Loader />
      ) : data?.length ? (
        <div className="grid grid-3">{data.map((j) => <JobCard key={j._id} job={j} />)}</div>
      ) : (
        !error && <div className="card empty">No jobs match your search.</div>
      )}
    </>
  );
}
