import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

export default function JobDetails() {
  const { id } = useParams();
  const { data: job, loading, error, reload } = useFetch(`/jobs/${id}`);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [applying, setApplying] = useState(false);

  if (loading) return <Loader />;
  if (error) return <><Alert message={error} /><Link to="/jobs">Back to jobs</Link></>;

  const closed = new Date(job.deadline) < new Date();

  const apply = async () => {
    setMsg({ type: "", text: "" });
    setApplying(true);
    try {
      await api.post(`/applications/${job._id}`);
      setMsg({ type: "success", text: "Application submitted. Track it under My applications." });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setApplying(false);
    }
  };

  return (
    <>
      <Link to="/jobs" className="small">Back to jobs</Link>
      <div className="card" style={{ marginTop: "0.75rem" }}>
        <div className="row-between">
          <div>
            <h1>{job.title}</h1>
            <p className="muted">{job.company?.name} {job.company?.location && `- ${job.company.location}`}</p>
          </div>
          {job.applied && <span className="badge badge-Selected">Applied</span>}
        </div>

        <Alert type={msg.type || "info"} message={msg.text} />

        <ul className="job-meta">
          <li>{job.location}</li><li>{job.type}</li>
          {job.salary && <li>{job.salary}</li>}
        </ul>

        <h3 style={{ marginTop: "1rem" }}>About the role</h3>
        <p style={{ whiteSpace: "pre-line" }}>{job.description}</p>

        <h3>Eligibility</h3>
        <ul>
          <li>Minimum CGPA: {job.minCgpa}</li>
          <li>Branches: {job.eligibleBranches?.length ? job.eligibleBranches.join(", ") : "All branches"}</li>
          <li>Graduation year: {job.graduationYear || "Any"}</li>
          <li>Apply by: {new Date(job.deadline).toLocaleDateString()}</li>
        </ul>

        {job.company?.description && (<><h3>About {job.company.name}</h3><p>{job.company.description}</p></>)}

        {!job.eligible && !job.applied && <Alert type="info" message={job.reason} />}
        <button className="btn btn-primary" onClick={apply} disabled={applying || job.applied || closed || !job.eligible}>
          {job.applied ? "Already applied" : closed ? "Deadline passed" : applying ? "Applying..." : "Apply now"}
        </button>
        {!job.eligible && job.reason.includes("profile") && <> <Link to="/profile" className="btn btn-outline">Complete profile</Link></>}
      </div>
    </>
  );
}
