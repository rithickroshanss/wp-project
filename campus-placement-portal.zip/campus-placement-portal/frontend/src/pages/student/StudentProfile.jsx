import { useEffect, useState } from "react";
import api, { downloadFile, errMsg } from "../../api/axios";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

const BRANCHES = ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"];

export default function StudentProfile() {
  const [form, setForm] = useState(null);
  const [resume, setResume] = useState(null);
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const fill = (p) => {
    setForm({
      name: p.name || "",
      email: p.email || "",
      rollNumber: p.rollNumber || "",
      branch: p.branch || "",
      cgpa: p.cgpa ?? "",
      graduationYear: p.graduationYear ?? "",
      phone: p.phone || "",
      skills: (p.skills || []).join(", "),
    });
    setResume(p.resume?.originalName ? p.resume : null);
  };

  useEffect(() => {
    api.get("/profile").then((r) => fill(r.data)).catch((e) => setMsg({ type: "error", text: errMsg(e) }));
  }, []);

  if (!form) return msg.text ? <Alert message={msg.text} /> : <Loader />;

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!form.name.trim()) return setMsg({ type: "error", text: "Name cannot be empty." });
    if (form.cgpa !== "" && (form.cgpa < 0 || form.cgpa > 10)) return setMsg({ type: "error", text: "CGPA must be between 0 and 10." });
    setSaving(true);
    try {
      const { data } = await api.put("/profile", form);
      fill(data);
      setMsg({ type: "success", text: "Profile saved." });
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setSaving(false);
    }
  };

  const upload = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!file) return setMsg({ type: "error", text: "Choose a PDF, DOC or DOCX file first." });
    if (file.size > 2 * 1024 * 1024) return setMsg({ type: "error", text: "Resume must be 2 MB or smaller." });
    const body = new FormData();
    body.append("resume", file);
    setUploading(true);
    try {
      const { data } = await api.post("/profile/resume", body);
      fill(data);
      setFile(null);
      e.target.reset();
      setMsg({ type: "success", text: "Resume uploaded." });
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setUploading(false);
    }
  };

  const view = () => downloadFile("/profile/resume", resume.originalName).catch(() => setMsg({ type: "error", text: "Could not download the resume." }));

  return (
    <>
      <div className="page-head">
        <h1>My profile</h1>
        <p className="muted">Companies set rules on CGPA, branch and batch. Keep these details correct so you can apply.</p>
      </div>
      <Alert type={msg.type || "info"} message={msg.text} />

      <div className="grid grid-2" style={{ alignItems: "start" }}>
        <form className="card" onSubmit={save} noValidate>
          <h3>Academic details</h3>
          <div className="form-grid">
            <div className="form-group"><label htmlFor="name">Full name</label><input id="name" name="name" value={form.name} onChange={change} /></div>
            <div className="form-group"><label htmlFor="email">Email</label><input id="email" value={form.email} disabled /></div>
            <div className="form-group"><label htmlFor="rollNumber">Roll number</label><input id="rollNumber" name="rollNumber" value={form.rollNumber} onChange={change} /></div>
            <div className="form-group">
              <label htmlFor="branch">Branch</label>
              <select id="branch" name="branch" value={form.branch} onChange={change}>
                <option value="">Select branch</option>
                {BRANCHES.map((b) => <option key={b}>{b}</option>)}
              </select>
            </div>
            <div className="form-group"><label htmlFor="cgpa">CGPA (0 to 10)</label><input id="cgpa" name="cgpa" type="number" step="0.01" min="0" max="10" value={form.cgpa} onChange={change} /></div>
            <div className="form-group"><label htmlFor="graduationYear">Graduation year</label><input id="graduationYear" name="graduationYear" type="number" min="2000" max="2100" value={form.graduationYear} onChange={change} /></div>
            <div className="form-group"><label htmlFor="phone">Phone</label><input id="phone" name="phone" value={form.phone} onChange={change} /></div>
            <div className="form-group"><label htmlFor="skills">Skills (separate with commas)</label><input id="skills" name="skills" value={form.skills} onChange={change} placeholder="React, Java, SQL" /></div>
          </div>
          <button className="btn btn-primary" disabled={saving}>{saving ? "Saving..." : "Save profile"}</button>
        </form>

        <form className="card" onSubmit={upload}>
          <h3>Resume</h3>
          {resume ? (
            <p>Current file: <strong>{resume.originalName}</strong> <button type="button" className="btn btn-outline btn-sm" onClick={view}>Download</button></p>
          ) : (
            <p className="muted">No resume uploaded yet.</p>
          )}
          <div className="form-group">
            <label htmlFor="resume">Upload a new resume (PDF, DOC or DOCX, max 2 MB)</label>
            <input id="resume" type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files[0] || null)} />
          </div>
          <button className="btn btn-primary" disabled={uploading}>{uploading ? "Uploading..." : "Upload resume"}</button>
        </form>
      </div>
    </>
  );
}
