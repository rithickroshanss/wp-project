import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

export default function MyApplications() {
  const { data, loading, error } = useFetch("/applications/my");

  return (
    <>
      <div className="page-head">
        <h1>My applications</h1>
        <p className="muted">Status is updated by the placement officer.</p>
      </div>
      <Alert message={error} />
      {loading ? (
        <Loader />
      ) : data?.length ? (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Company</th><th>Role</th><th>Location</th><th>Applied on</th><th>Status</th></tr>
            </thead>
            <tbody>
              {data.map((a) => (
                <tr key={a._id}>
                  <td>{a.job.company?.name}</td>
                  <td><Link to={`/jobs/${a.job._id}`}>{a.job.title}</Link></td>
                  <td>{a.job.location}</td>
                  <td>{new Date(a.createdAt).toLocaleDateString()}</td>
                  <td><span className={`badge badge-${a.status}`}>{a.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !error && <div className="card empty">You have not applied to any job yet. <Link to="/jobs">Browse jobs</Link></div>
      )}
    </>
  );
}
