import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";
import StatCard from "../../components/StatCard";
import JobCard from "../../components/JobCard";

export default function StudentDashboard() {
  const { user } = useAuth();
  const apps = useFetch("/applications/my");
  const jobs = useFetch("/jobs?eligible=true");
  const news = useFetch("/announcements");

  if (apps.loading || jobs.loading || news.loading) return <Loader />;

  const list = apps.data || [];
  const count = (s) => list.filter((a) => a.status === s).length;

  return (
    <>
      <div className="page-head">
        <h1>Welcome, {user.name.split(" ")[0]}</h1>
        <p className="muted">Here is where your placement search stands today.</p>
      </div>
      <Alert message={apps.error || jobs.error || news.error} />

      <div className="grid grid-4">
        <StatCard label="Applications" value={list.length} />
        <StatCard label="Shortlisted" value={count("Shortlisted")} />
        <StatCard label="Selected" value={count("Selected")} />
        <StatCard label="Open jobs for you" value={jobs.data?.filter((j) => !j.applied).length} />
      </div>

      <div className="row-between" style={{ margin: "1.75rem 0 0.75rem" }}>
        <h2 style={{ margin: 0 }}>Jobs you can apply to</h2>
        <Link to="/jobs" className="btn btn-outline btn-sm">See all jobs</Link>
      </div>
      {jobs.data?.length ? (
        <div className="grid grid-3">
          {jobs.data.slice(0, 3).map((j) => <JobCard key={j._id} job={j} />)}
        </div>
      ) : (
        <div className="card empty">
          No matching jobs yet. <Link to="/profile">Complete your profile</Link> so we can check your eligibility.
        </div>
      )}

      <h2 style={{ margin: "1.75rem 0 0.75rem" }}>Latest announcements</h2>
      {news.data?.length ? (
        <div className="grid">
          {news.data.slice(0, 3).map((n) => (
            <div key={n._id} className="card announce">
              <h3>{n.title}</h3>
              <p>{n.message}</p>
              <span className="small muted">{new Date(n.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      ) : (
        <div className="card empty">No announcements yet.</div>
      )}
    </>
  );
}
