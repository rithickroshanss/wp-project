import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { errMsg } from "../api/axios";
import Alert from "../components/Alert";

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (user) return <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />;

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (!form.name.trim()) return setError("Please enter your name.");
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError("Please enter a valid email.");
    if (form.password.length < 6) return setError("Password must be at least 6 characters.");
    if (form.password !== form.confirm) return setError("Passwords do not match.");
    setLoading(true);
    try {
      await register(form.name, form.email, form.password);
      navigate("/profile"); // new students fill in their profile first
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card auth-card">
      <h2>Create your student account</h2>
      <Alert message={error} />
      <form onSubmit={submit} noValidate>
        <div className="form-group">
          <label htmlFor="name">Full name</label>
          <input id="name" name="name" value={form.name} onChange={change} autoComplete="name" />
        </div>
        <div className="form-group">
          <label htmlFor="email">College email</label>
          <input id="email" name="email" type="email" value={form.email} onChange={change} autoComplete="email" />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input id="password" name="password" type="password" value={form.password} onChange={change} autoComplete="new-password" />
        </div>
        <div className="form-group">
          <label htmlFor="confirm">Confirm password</label>
          <input id="confirm" name="confirm" type="password" value={form.confirm} onChange={change} autoComplete="new-password" />
        </div>
        <button className="btn btn-primary" style={{ width: "100%" }} disabled={loading}>
          {loading ? "Creating account..." : "Create account"}
        </button>
      </form>
      <p className="small" style={{ marginTop: "1rem" }}>
        Already registered? <Link to="/login">Log in</Link>
      </p>
    </div>
  );
}
