import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { downloadFile, errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

const STATUSES = ["Applied", "Shortlisted", "Selected", "Rejected"];

export default function ViewApplicants() {
  const { jobId } = useParams();
  const { data, loading, error, reload } = useFetch(`/admin/jobs/${jobId}/applicants`);
  const [msg, setMsg] = useState({ type: "", text: "" });

  const setStatus = async (applicationId, status) => {
    try {
      await api.put(`/admin/applications/${applicationId}/status`, { status });
      setMsg({ type: "success", text: `Status changed to ${status}.` });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    }
  };

  const resume = (a) =>
    downloadFile(`/admin/students/${a.student._id}/resume`, `${a.student.name}-resume`).catch(() => setMsg({ type: "error", text: "Could not download the resume." }));

  if (loading) return <Loader />;
  if (error) return <><Alert message={error} /><Link to="/admin/jobs">Back to jobs</Link></>;

  return (
    <>
      <Link to="/admin/jobs" className="small">Back to jobs</Link>
      <div className="page-head" style={{ marginTop: "0.5rem" }}>
        <h1>Applicants</h1>
        <p className="muted">{data.job.title} at {data.job.company} ({data.applicants.length} applied)</p>
      </div>
      <Alert type={msg.type || "info"} message={msg.text} />

      {data.applicants.length ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Student</th><th>Roll no.</th><th>Branch</th><th>CGPA</th><th>Applied on</th><th>Status</th><th>Resume</th></tr></thead>
            <tbody>
              {data.applicants.map((a) => (
                <tr key={a._id}>
                  <td>{a.student.name}<br /><span className="small muted">{a.student.email}</span></td>
                  <td>{a.rollNumber || "-"}</td>
                  <td>{a.branch || "-"}</td>
                  <td>{a.cgpa ?? "-"}</td>
                  <td>{new Date(a.appliedAt).toLocaleDateString()}</td>
                  <td>
                    <select aria-label={`Status for ${a.student.name}`} value={a.status} onChange={(e) => setStatus(a._id, e.target.value)}>
                      {STATUSES.map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </td>
                  <td>{a.hasResume ? <button className="btn btn-outline btn-sm" onClick={() => resume(a)}>Download</button> : "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="card empty">No one has applied to this job yet.</div>
      )}
    </>
  );
}
