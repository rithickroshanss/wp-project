import { Link } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";
import StatCard from "../../components/StatCard";

export default function AdminDashboard() {
  const { data, loading, error } = useFetch("/admin/stats");

  if (loading) return <Loader />;

  return (
    <>
      <div className="page-head">
        <h1>Placement dashboard</h1>
        <p className="muted">A quick look at the current placement season.</p>
      </div>
      <Alert message={error} />
      {data && (
        <>
          <div className="grid grid-4">
            <StatCard label="Students" value={data.students} />
            <StatCard label="Companies" value={data.companies} />
            <StatCard label="Jobs" value={data.jobs} />
            <StatCard label="Applications" value={data.applications} />
          </div>

          <h2 style={{ margin: "1.75rem 0 0.75rem" }}>Applications by status</h2>
          <div className="grid grid-4">
            {Object.entries(data.byStatus).map(([status, count]) => (
              <div key={status} className="card">
                <span className={`badge badge-${status}`}>{status}</span>
                <div className="stat-value">{count}</div>
              </div>
            ))}
          </div>

          <h2 style={{ margin: "1.75rem 0 0.75rem" }}>Quick actions</h2>
          <div className="row">
            <Link to="/admin/jobs" className="btn btn-primary">Post or manage jobs</Link>
            <Link to="/admin/companies" className="btn btn-outline">Add a company</Link>
            <Link to="/admin/announcements" className="btn btn-outline">Publish an announcement</Link>
          </div>
        </>
      )}
    </>
  );
}
