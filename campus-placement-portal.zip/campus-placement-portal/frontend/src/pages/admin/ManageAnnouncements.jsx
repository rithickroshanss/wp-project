import { useState } from "react";
import api, { errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

export default function ManageAnnouncements() {
  const { data, loading, error, reload } = useFetch("/announcements");
  const [form, setForm] = useState({ title: "", message: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!form.title.trim() || !form.message.trim()) return setMsg({ type: "error", text: "Title and message are required." });
    setSaving(true);
    try {
      await api.post("/announcements", form);
      setForm({ title: "", message: "" });
      setMsg({ type: "success", text: "Announcement published." });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (n) => {
    if (!window.confirm(`Delete "${n.title}"?`)) return;
    try {
      await api.delete(`/announcements/${n._id}`);
      setMsg({ type: "success", text: "Announcement deleted." });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    }
  };

  return (
    <>
      <div className="page-head"><h1>Announcements</h1></div>
      <Alert type={msg.type || "info"} message={msg.text} />

      <form className="card" onSubmit={submit} noValidate style={{ marginBottom: "1.5rem" }}>
        <h3>Publish an announcement</h3>
        <div className="form-group"><label htmlFor="title">Title</label><input id="title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
        <div className="form-group"><label htmlFor="message">Message</label><textarea id="message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
        <button className="btn btn-primary" disabled={saving}>{saving ? "Publishing..." : "Publish"}</button>
      </form>

      <Alert message={error} />
      {loading ? (
        <Loader />
      ) : data?.length ? (
        <div className="grid">
          {data.map((n) => (
            <article key={n._id} className="card announce">
              <div className="row-between">
                <h3>{n.title}</h3>
                <button className="btn btn-danger btn-sm" onClick={() => remove(n)}>Delete</button>
              </div>
              <p style={{ whiteSpace: "pre-line" }}>{n.message}</p>
              <span className="small muted">{new Date(n.createdAt).toLocaleDateString()}</span>
            </article>
          ))}
        </div>
      ) : (
        !error && <div className="card empty">No announcements published yet.</div>
      )}
    </>
  );
}
