import { useState } from "react";
import { Link } from "react-router-dom";
import api, { errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

const BRANCHES = ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"];
const blank = {
  company: "", title: "", description: "", location: "", type: "Full-time", salary: "",
  minCgpa: "", eligibleBranches: [], graduationYear: "", deadline: "", isActive: true,
};

export default function ManageJobs() {
  const jobs = useFetch("/jobs");
  const companies = useFetch("/companies");
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const toggleBranch = (b) =>
    setForm({
      ...form,
      eligibleBranches: form.eligibleBranches.includes(b) ? form.eligibleBranches.filter((x) => x !== b) : [...form.eligibleBranches, b],
    });
  const cancel = () => { setForm(blank); setEditId(null); };

  const submit = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!form.company) return setMsg({ type: "error", text: "Select a company." });
    if (!form.title.trim() || !form.description.trim() || !form.location.trim()) return setMsg({ type: "error", text: "Title, description and location are required." });
    if (!form.deadline) return setMsg({ type: "error", text: "Choose an application deadline." });
    if (form.minCgpa !== "" && (form.minCgpa < 0 || form.minCgpa > 10)) return setMsg({ type: "error", text: "Minimum CGPA must be between 0 and 10." });

    const payload = { ...form, minCgpa: form.minCgpa === "" ? 0 : Number(form.minCgpa), graduationYear: form.graduationYear ? Number(form.graduationYear) : null };
    setSaving(true);
    try {
      if (editId) await api.put(`/jobs/${editId}`, payload);
      else await api.post("/jobs", payload);
      setMsg({ type: "success", text: editId ? "Job updated." : "Job posted." });
      cancel();
      jobs.reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setSaving(false);
    }
  };

  const edit = (j) => {
    setEditId(j._id);
    setForm({
      company: j.company?._id || "", title: j.title, description: j.description, location: j.location, type: j.type,
      salary: j.salary || "", minCgpa: j.minCgpa ?? "", eligibleBranches: j.eligibleBranches || [],
      graduationYear: j.graduationYear || "", deadline: j.deadline.slice(0, 10), isActive: j.isActive,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (j) => {
    if (!window.confirm(`Delete "${j.title}" and all its applications?`)) return;
    try {
      await api.delete(`/jobs/${j._id}`);
      setMsg({ type: "success", text: "Job deleted." });
      jobs.reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    }
  };

  if (jobs.loading || companies.loading) return <Loader />;

  return (
    <>
      <div className="page-head"><h1>Jobs</h1></div>
      <Alert type={msg.type || "info"} message={msg.text} />
      <Alert message={jobs.error || companies.error} />
      {!companies.data?.length && <Alert type="info" message="Add a company first, then you can post jobs for it." />}

      <form className="card" onSubmit={submit} noValidate style={{ marginBottom: "1.5rem" }}>
        <h3>{editId ? "Edit job" : "Post a job"}</h3>
        <div className="form-grid">
          <div className="form-group">
            <label htmlFor="company">Company</label>
            <select id="company" name="company" value={form.company} onChange={change}>
              <option value="">Select company</option>
              {companies.data?.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
          </div>
          <div className="form-group"><label htmlFor="title">Job title</label><input id="title" name="title" value={form.title} onChange={change} /></div>
          <div className="form-group"><label htmlFor="location">Location</label><input id="location" name="location" value={form.location} onChange={change} /></div>
          <div className="form-group">
            <label htmlFor="type">Type</label>
            <select id="type" name="type" value={form.type} onChange={change}><option>Full-time</option><option>Internship</option></select>
          </div>
          <div className="form-group"><label htmlFor="salary">Salary / stipend</label><input id="salary" name="salary" value={form.salary} onChange={change} placeholder="6 LPA" /></div>
          <div className="form-group"><label htmlFor="deadline">Apply by</label><input id="deadline" name="deadline" type="date" value={form.deadline} onChange={change} /></div>
          <div className="form-group"><label htmlFor="minCgpa">Minimum CGPA</label><input id="minCgpa" name="minCgpa" type="number" step="0.1" min="0" max="10" value={form.minCgpa} onChange={change} /></div>
          <div className="form-group"><label htmlFor="graduationYear">Graduation year (blank = any)</label><input id="graduationYear" name="graduationYear" type="number" value={form.graduationYear} onChange={change} /></div>
        </div>
        <div className="form-group">
          <label>Eligible branches (none selected = all branches)</label>
          <div className="checks">
            {BRANCHES.map((b) => (
              <label key={b}><input type="checkbox" checked={form.eligibleBranches.includes(b)} onChange={() => toggleBranch(b)} /> {b}</label>
            ))}
          </div>
        </div>
        <div className="form-group"><label htmlFor="description">Description</label><textarea id="description" name="description" value={form.description} onChange={change} /></div>
        <div className="form-group checks">
          <label><input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} /> Visible to students</label>
        </div>
        <div className="row">
          <button className="btn btn-primary" disabled={saving}>{saving ? "Saving..." : editId ? "Save changes" : "Post job"}</button>
          {editId && <button type="button" className="btn btn-outline" onClick={cancel}>Cancel</button>}
        </div>
      </form>

      {jobs.data?.length ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Role</th><th>Company</th><th>Eligibility</th><th>Deadline</th><th>Visible</th><th>Actions</th></tr></thead>
            <tbody>
              {jobs.data.map((j) => (
                <tr key={j._id}>
                  <td>{j.title}<br /><span className="small muted">{j.location}</span></td>
                  <td>{j.company?.name}</td>
                  <td>CGPA {j.minCgpa}+<br /><span className="small muted">{j.eligibleBranches?.length ? j.eligibleBranches.join(", ") : "All branches"}{j.graduationYear ? `, ${j.graduationYear}` : ""}</span></td>
                  <td>{new Date(j.deadline).toLocaleDateString()}</td>
                  <td>{j.isActive ? "Yes" : "No"}</td>
                  <td>
                    <div className="actions">
                      <Link to={`/admin/jobs/${j._id}/applicants`} className="btn btn-primary btn-sm">Applicants</Link>
                      <button className="btn btn-outline btn-sm" onClick={() => edit(j)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => remove(j)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !jobs.error && <div className="card empty">No jobs posted yet.</div>
      )}
    </>
  );
}
