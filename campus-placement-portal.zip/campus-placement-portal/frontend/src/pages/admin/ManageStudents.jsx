import { useState } from "react";
import api, { downloadFile, errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

export default function ManageStudents() {
  const { data, loading, error, reload } = useFetch("/admin/students");
  const [search, setSearch] = useState("");
  const [msg, setMsg] = useState({ type: "", text: "" });

  const remove = async (s) => {
    if (!window.confirm(`Remove ${s.name}? Their profile, resume and applications will be deleted.`)) return;
    try {
      await api.delete(`/admin/students/${s._id}`);
      setMsg({ type: "success", text: "Student removed." });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    }
  };

  const resume = (s) =>
    downloadFile(`/admin/students/${s._id}/resume`, `${s.name}-resume`).catch(() => setMsg({ type: "error", text: "Could not download the resume." }));

  const q = search.toLowerCase();
  const rows = (data || []).filter((s) => [s.name, s.email, s.rollNumber, s.branch].some((v) => v?.toLowerCase().includes(q)));

  return (
    <>
      <div className="page-head">
        <h1>Students</h1>
        <p className="muted">{data ? `${data.length} registered` : ""}</p>
      </div>
      <Alert message={error} />
      <Alert type={msg.type || "info"} message={msg.text} />
      <div className="form-group" style={{ maxWidth: 360 }}>
        <label htmlFor="search">Search by name, email, roll number or branch</label>
        <input id="search" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {loading ? (
        <Loader />
      ) : rows.length ? (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Name</th><th>Roll no.</th><th>Branch</th><th>CGPA</th><th>Batch</th><th>Skills</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s._id}>
                  <td>{s.name}<br /><span className="small muted">{s.email}</span></td>
                  <td>{s.rollNumber || "-"}</td>
                  <td>{s.branch || "-"}</td>
                  <td>{s.cgpa ?? "-"}</td>
                  <td>{s.graduationYear || "-"}</td>
                  <td>{s.skills.join(", ") || "-"}</td>
                  <td>
                    <div className="actions">
                      {s.hasResume && <button className="btn btn-outline btn-sm" onClick={() => resume(s)}>Resume</button>}
                      <button className="btn btn-danger btn-sm" onClick={() => remove(s)}>Remove</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !error && <div className="card empty">No students found.</div>
      )}
    </>
  );
}
