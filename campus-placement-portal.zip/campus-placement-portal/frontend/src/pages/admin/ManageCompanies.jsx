import { useState } from "react";
import api, { errMsg } from "../../api/axios";
import useFetch from "../../hooks/useFetch";
import Loader from "../../components/Loader";
import Alert from "../../components/Alert";

const blank = { name: "", description: "", website: "", location: "" };

export default function ManageCompanies() {
  const { data, loading, error, reload } = useFetch("/companies");
  const [form, setForm] = useState(blank);
  const [editId, setEditId] = useState(null);
  const [msg, setMsg] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const cancel = () => { setForm(blank); setEditId(null); };

  const submit = async (e) => {
    e.preventDefault();
    setMsg({ type: "", text: "" });
    if (!form.name.trim()) return setMsg({ type: "error", text: "Company name is required." });
    setSaving(true);
    try {
      if (editId) await api.put(`/companies/${editId}`, form);
      else await api.post("/companies", form);
      setMsg({ type: "success", text: editId ? "Company updated." : "Company added." });
      cancel();
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    } finally {
      setSaving(false);
    }
  };

  const edit = (c) => {
    setEditId(c._id);
    setForm({ name: c.name, description: c.description || "", website: c.website || "", location: c.location || "" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async (c) => {
    if (!window.confirm(`Delete ${c.name}?`)) return;
    try {
      await api.delete(`/companies/${c._id}`);
      setMsg({ type: "success", text: "Company deleted." });
      reload();
    } catch (err) {
      setMsg({ type: "error", text: errMsg(err) });
    }
  };

  return (
    <>
      <div className="page-head"><h1>Companies</h1></div>
      <Alert type={msg.type || "info"} message={msg.text} />

      <form className="card" onSubmit={submit} noValidate style={{ marginBottom: "1.5rem" }}>
        <h3>{editId ? "Edit company" : "Add a company"}</h3>
        <div className="form-grid">
          <div className="form-group"><label htmlFor="name">Name</label><input id="name" name="name" value={form.name} onChange={change} /></div>
          <div className="form-group"><label htmlFor="location">Location</label><input id="location" name="location" value={form.location} onChange={change} /></div>
          <div className="form-group"><label htmlFor="website">Website</label><input id="website" name="website" value={form.website} onChange={change} placeholder="https://" /></div>
        </div>
        <div className="form-group"><label htmlFor="description">Description</label><textarea id="description" name="description" value={form.description} onChange={change} /></div>
        <div className="row">
          <button className="btn btn-primary" disabled={saving}>{saving ? "Saving..." : editId ? "Save changes" : "Add company"}</button>
          {editId && <button type="button" className="btn btn-outline" onClick={cancel}>Cancel</button>}
        </div>
      </form>

      <Alert message={error} />
      {loading ? (
        <Loader />
      ) : data?.length ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Company</th><th>Location</th><th>Website</th><th>Actions</th></tr></thead>
            <tbody>
              {data.map((c) => (
                <tr key={c._id}>
                  <td>{c.name}</td>
                  <td>{c.location || "-"}</td>
                  <td>{c.website ? <a href={c.website} target="_blank" rel="noreferrer">{c.website}</a> : "-"}</td>
                  <td>
                    <div className="actions">
                      <button className="btn btn-outline btn-sm" onClick={() => edit(c)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => remove(c)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        !error && <div className="card empty">No companies yet. Add the first one above.</div>
      )}
    </>
  );
}
