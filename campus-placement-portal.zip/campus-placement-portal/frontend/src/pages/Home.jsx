import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Home() {
  const { user } = useAuth();
  const dashboard = user?.role === "admin" ? "/admin" : "/dashboard";

  return (
    <>
      <section className="hero">
        <h1>Find your first job right here on campus.</h1>
        <p>
          See every company visiting your college, check if you are eligible, apply in one click and follow your
          application from Applied to Selected.
        </p>
        <div className="row">
          {user ? (
            <Link to={dashboard} className="btn btn-accent">Go to my dashboard</Link>
          ) : (
            <>
              <Link to="/register" className="btn btn-accent">Create student account</Link>
              <Link to="/login" className="btn btn-light">Log in</Link>
            </>
          )}
        </div>
      </section>

      <section className="grid grid-3">
        <div className="card feature">
          <h3>For students</h3>
          <p>Keep one profile with your CGPA, skills and resume. Search jobs by company, role and location, and see right away which ones you can apply to.</p>
        </div>
        <div className="card feature">
          <h3>For placement officers</h3>
          <p>Add companies, post jobs with eligibility rules, review applicants and update their status from one dashboard.</p>
        </div>
        <div className="card feature">
          <h3>Always up to date</h3>
          <p>Announcements about talks, tests and deadlines are published here, so nobody misses a notice.</p>
        </div>
      </section>
    </>
  );
}
