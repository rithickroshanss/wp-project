import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="card empty">
      <h1>404</h1>
      <p>We could not find the page you are looking for.</p>
      <Link to="/" className="btn btn-primary">Back to home</Link>
    </div>
  );
}
