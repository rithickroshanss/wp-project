import axios from "axios";

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "/api" });

// Send the login token with every request.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turn any error into a short message for the user.
export const errMsg = (err) => err.response?.data?.message || "Something went wrong. Please try again.";

// Downloads a protected file (e.g. a resume) using the login token.
export async function downloadFile(url, filename = "resume") {
  const res = await api.get(url, { responseType: "blob" });
  // Use the real file name (with .pdf/.docx) sent by the server, if available.
  const match = /filename="?([^";]+)"?/.exec(res.headers["content-disposition"] || "");
  const link = document.createElement("a");
  link.href = URL.createObjectURL(res.data);
  link.download = match ? decodeURIComponent(match[1]) : filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

export default api;
