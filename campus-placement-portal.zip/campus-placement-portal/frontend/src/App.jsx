import { Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ProtectedRoute from "./components/ProtectedRoute";

import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

import StudentDashboard from "./pages/student/StudentDashboard";
import StudentProfile from "./pages/student/StudentProfile";
import Jobs from "./pages/student/Jobs";
import JobDetails from "./pages/student/JobDetails";
import MyApplications from "./pages/student/MyApplications";
import Announcements from "./pages/student/Announcements";

import AdminDashboard from "./pages/admin/AdminDashboard";
import ManageStudents from "./pages/admin/ManageStudents";
import ManageCompanies from "./pages/admin/ManageCompanies";
import ManageJobs from "./pages/admin/ManageJobs";
import ViewApplicants from "./pages/admin/ViewApplicants";
import ManageAnnouncements from "./pages/admin/ManageAnnouncements";

const student = (el) => <ProtectedRoute role="student">{el}</ProtectedRoute>;
const admin = (el) => <ProtectedRoute role="admin">{el}</ProtectedRoute>;

export default function App() {
  return (
    <div className="app">
      <Navbar />
      <main className="container main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />

          <Route path="/dashboard" element={student(<StudentDashboard />)} />
          <Route path="/profile" element={student(<StudentProfile />)} />
          <Route path="/jobs" element={student(<Jobs />)} />
          <Route path="/jobs/:id" element={student(<JobDetails />)} />
          <Route path="/applications" element={student(<MyApplications />)} />
          <Route path="/announcements" element={student(<Announcements />)} />

          <Route path="/admin" element={admin(<AdminDashboard />)} />
          <Route path="/admin/students" element={admin(<ManageStudents />)} />
          <Route path="/admin/companies" element={admin(<ManageCompanies />)} />
          <Route path="/admin/jobs" element={admin(<ManageJobs />)} />
          <Route path="/admin/jobs/:jobId/applicants" element={admin(<ViewApplicants />)} />
          <Route path="/admin/announcements" element={admin(<ManageAnnouncements />)} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
